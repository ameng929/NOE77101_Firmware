
var config = 
{ 
  logo:         "../images/Telemecanique.gif",
  logoPocketPC: "../images/TelemecaniquePocketPC.gif",
  titleHtml:    "NOE 771 01 Web Server",
  title:        "NOE 771 01 Web Server",
  titleColor:   "White",
  titleBgColor: "#0077BB",
  homeImage:     "../../images/noe77101.jpg",
  homeVersion:   "Web site version : 3.1",
  homeCopyRight: "Copyright &copy; 1998-2006, Schneider Automation SAS. All rights reserved."
}

